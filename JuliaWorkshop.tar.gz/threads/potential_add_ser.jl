
function lennard_jones(x1, x2)
    r = abs(x1-x2)
    inv = (1.e-8/r)^6
    u = inv*(inv-1)
    return u
end

function potential(v)
    U = 0
    for i = 1:length(v)-1
        for j = i+1:length(v)
            U += lennard_jones(v[i],v[j])
        end
    end
    return U
end


#-----------------------------------
N = parse(Int64, ARGS[1])

v = rand(N).*10

@time u = potential(v)

println(u/N)
