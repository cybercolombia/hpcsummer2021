using Test

function foo(x)
    for i = 2:10000
        x *= (i-1)/(i+1)
    end
    return x
end

function calc!(v)
    Threads.@threads for i = 1:length(v)
        v[i] = foo(v[i]) 
    end
end

#-----------------------------
N = parse(Int64, ARGS[1])

a = fill(1.0,N)

x = 1
x = foo(x)
#println(x)

@time begin
    calc!(a)
end

@test all(a .== x)
