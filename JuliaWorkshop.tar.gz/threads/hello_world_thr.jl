#First example: parallel for
Threads.@threads for i = 1:Threads.nthreads()
    println("Hello from thread ",Threads.threadid())
end
