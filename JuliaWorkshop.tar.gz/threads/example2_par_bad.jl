using Test

function add(v)
    res = 0
    Threads.@threads for i = 1:length(v)
        res += v[i]
    end
    return res
end

#-----------------------------
N = parse(Int64, ARGS[1])

a = ones(N)

@time begin
    r = add(a)
end

@test r == N
