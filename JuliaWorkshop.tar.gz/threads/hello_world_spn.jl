Threads.@sync for i = 1:Threads.nthreads()
    Threads.@spawn println("Hello from thread ",Threads.threadid())
end
