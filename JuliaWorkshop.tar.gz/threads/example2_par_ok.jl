using Test

function add(v)
    partial_res = zeros(Threads.nthreads())
    Threads.@threads for i = 1:length(v)
        partial_res[Threads.threadid()] += v[i]
    end
    return sum(partial_res)
end

#-----------------------------
N = parse(Int64, ARGS[1])

a = ones(N)

@time begin
    r = add(a)
end

@test r == N
