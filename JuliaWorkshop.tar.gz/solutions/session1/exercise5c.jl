using Test


function dot_prod!(A, B, C, i, j)
    c = 0 #local object
    for k = 1:size(A, 2)
        c += A[i,k] * B[k,j] #add to local object
    end
    C[i,j] = c
end
    
function mat_prod!(A, B, C)
    for i = 1:size(A, 1)
        for j = 1:size(B, 2)
            dot_prod!(A, B, C, i, j)
        end
    end
end

#------------------------------
N = parse(Int64, ARGS[1])

A = fill(1,100,N)
B = fill(1,N,80)
C = Array{Float64}(undef, size(A, 1), size(B, 2))

@time begin
    mat_prod!(A, B, C)
end

@test all(C .== N)
