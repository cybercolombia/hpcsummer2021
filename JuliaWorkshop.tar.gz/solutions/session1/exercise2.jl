
a = [-5:3:22;]
println(a)

m = reshape(a,(5,2))
println(m)

println(m[3:5,2])
