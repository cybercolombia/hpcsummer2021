function which_triangle(side1,side2,side3)
    if side1==side2 && side2==side3
        println("Equilateral")
    elseif side1==side2 || side2==side3 || side1==side3
        println("Isosceles")
    else
        println("Scalene")
    end
end


which_triangle(2,3,1)
which_triangle(1,3,1)
which_triangle(2,2,2)
