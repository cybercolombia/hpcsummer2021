f2c(f) = (f-32)/1.8

println(f2c(0))
