function largest(x, y, z)
    if x >= y && x >= z
        return x
    elseif y >= z
        return y
    else
        return z
    end
end



println(largest(-3,6,-1))
    
