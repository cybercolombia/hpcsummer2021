x = sqrt(Complex((3-5)*2))+3^3
println(x)

λ = (8 !== 2^3) || (5%2 !== 0)
print(λ)
