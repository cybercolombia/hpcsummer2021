using Test

function dot_prod(a, b)
    c = 0
    for i = 1:length(a)
        c += a[i] * b[i]
    end
    return c
end

#------------------------
N = parse(Int64, ARGS[1])

a = fill(1,1,N)
b = fill(2,1,N)

@time begin
    c = dot_prod(a,b)
end

@test c == 2*N

