function even(x)
    return x%2 == 0
end


println(even(56))
println(even(37))
