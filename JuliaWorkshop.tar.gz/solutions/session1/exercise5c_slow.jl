using Test


function mat_prod!(A, B, C)
    for i = 1:size(A, 1)
        for j = 1:size(B, 2)

            C[i,j] = sum(A[i,:] .* B[:,j]) #Add to global object C
            
        end
    end
end

#------------------------------
N = parse(Int64, ARGS[1])

A = fill(1,100,N)
B = fill(1,N,80)
C = Array{Float64}(undef, size(A, 1), size(B, 2))

@time begin
    mat_prod!(A, B, C)
end

@test all(C .== N)
