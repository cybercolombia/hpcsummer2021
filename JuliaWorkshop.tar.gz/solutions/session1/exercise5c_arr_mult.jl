using Test

#------------------------------
N = parse(Int64, ARGS[1])

A = fill(1,100,N)
B = fill(1,N,80)

@time begin
    C = A * B
end

@test all(C .== N)
