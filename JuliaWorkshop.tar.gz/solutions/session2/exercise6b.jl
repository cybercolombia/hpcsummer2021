using Test

function dot_prod(a, b)
    nthr = Threads.nthreads()
    cv = zeros(nthr)
    Threads.@threads for i = 1:length(a) 
        cv[Threads.threadid()] += a[i]*b[i]
    end
    return sum(cv)
end

#------------------------
N = parse(Int64, ARGS[1])

a = fill(1,1,N)
b = fill(2,1,N)

@time begin
    c = dot_prod(a,b)
end

@test c == 2*N
