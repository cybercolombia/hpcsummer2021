using Test

function add_vec(a, b)
    c = Array{Int64}(undef,1,length(a))
    Threads.@threads for i = 1:length(a)
        c[i] = a[i] + b[i]
    end
    return c
end

#--------------------------
N = parse(Int64, ARGS[1])

a = fill(3,1,N)
b = fill(2,1,N)

@time begin
    c = add_vec(a, b)
end

@test all(c .== 5)
