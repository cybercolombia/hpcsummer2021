
function lennard_jones(x1, x2)
    r = abs(x1-x2)
    inv = (1.e-8/r)^6
    u = inv*(inv-1)
    return u
end

function potential(v)
    U = zeros(Threads.nthreads())
    Threads.@sync for i = 1:length(v)-1
        Threads.@spawn begin
            for j = i+1:length(v)
                U[Threads.threadid()] += lennard_jones(v[i],v[j])
            end
        end
    end
    return sum(U)
end


#-----------------------------------
N = parse(Int64, ARGS[1])

v = rand(N).*10

@time u = potential(v)

println(u/N)
