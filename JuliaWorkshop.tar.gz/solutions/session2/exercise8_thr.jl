using DelimitedFiles

const MAX_ITER = 1000
const MIN_RE = -2.0
const MAX_RE = 1.0
const MIN_IM = -1.0
const MAX_IM = 1.0

function is_in(c)
    z = 0 + 0im
    for i = 1:MAX_ITER
        z = z*z + c
        if abs2(z) > 4
            return false
        end
    end
    return true
end

function mandelbrot(A)
    nrows = size(A,1)
    ncols = size(A,2)
    stepx = (MAX_RE-MIN_RE) / ncols
    stepy = (MAX_IM-MIN_IM) / nrows
    Noutside = zeros(Threads.nthreads())

    Threads.@threads for i = 1:nrows
        for j = 1:ncols
            c = (stepx*(j-1)+MIN_RE) + (stepy*(i-1)+MIN_IM)im
            #println(real(c)," ",imag(c),"i")
            test = is_in(c)
            if test
                A[i,j] = 1
            else
                A[i,j] = 0
                Noutside[Threads.threadid()] += 1
            end
        end
    end
    return sum(Noutside)
end

#------------------------------------
nrows = parse(Int64, ARGS[1])
ncols = parse(Int64, ARGS[2])

A = Array{Int64}(undef, nrows, ncols)

@time nout = mandelbrot(A)

#println(A)
open("mandelbrot.dat", "w") do io
    writedlm(io, A)
end

a = (MAX_RE-MIN_RE)*(MAX_IM-MIN_IM)
tot = nrows*ncols
m_area = a * (tot-nout) / tot

println("Area: ",m_area)
